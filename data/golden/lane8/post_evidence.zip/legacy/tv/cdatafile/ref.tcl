set depth_list {
{mem 98560}
{input_r 1}
{weight 1}
{bias 1}
{output_r 1}
{ci 1}
{co 1}
{height 1}
{width 1}
{ap_return 1}
}
set trans_num 18
