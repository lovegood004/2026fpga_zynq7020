run all
quit
