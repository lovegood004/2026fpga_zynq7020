// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
 `timescale 1ns/1ps


`define AUTOTB_DUT      lung_conv_fp32
`define AUTOTB_DUT_INST AESL_inst_lung_conv_fp32
`define AUTOTB_TOP      apatb_lung_conv_fp32_top
`define AUTOTB_LAT_RESULT_FILE "lung_conv_fp32.result.lat.rb"
`define AUTOTB_PER_RESULT_TRANS_FILE "lung_conv_fp32.performance.result.transaction.xml"
`define AUTOTB_TOP_INST AESL_inst_apatb_lung_conv_fp32_top
`define AUTOTB_MAX_ALLOW_LATENCY  15000000
`define AUTOTB_CLOCK_PERIOD_DIV2 5.00

`define AESL_DEPTH_mem 1
`define AESL_DEPTH_input_r 1
`define AESL_DEPTH_weight 1
`define AESL_DEPTH_bias 1
`define AESL_DEPTH_output_r 1
`define AESL_DEPTH_ci 1
`define AESL_DEPTH_co 1
`define AESL_DEPTH_height 1
`define AESL_DEPTH_width 1
`define AUTOTB_TVIN_mem  "../tv/cdatafile/c.lung_conv_fp32.autotvin_mem.dat"
`define AUTOTB_TVIN_input_r  "../tv/cdatafile/c.lung_conv_fp32.autotvin_input_r.dat"
`define AUTOTB_TVIN_weight  "../tv/cdatafile/c.lung_conv_fp32.autotvin_weight.dat"
`define AUTOTB_TVIN_bias  "../tv/cdatafile/c.lung_conv_fp32.autotvin_bias.dat"
`define AUTOTB_TVIN_output_r  "../tv/cdatafile/c.lung_conv_fp32.autotvin_output_r.dat"
`define AUTOTB_TVIN_ci  "../tv/cdatafile/c.lung_conv_fp32.autotvin_ci.dat"
`define AUTOTB_TVIN_co  "../tv/cdatafile/c.lung_conv_fp32.autotvin_co.dat"
`define AUTOTB_TVIN_height  "../tv/cdatafile/c.lung_conv_fp32.autotvin_height.dat"
`define AUTOTB_TVIN_width  "../tv/cdatafile/c.lung_conv_fp32.autotvin_width.dat"
`define AUTOTB_TVIN_mem_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_mem.dat"
`define AUTOTB_TVIN_input_r_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_input_r.dat"
`define AUTOTB_TVIN_weight_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_weight.dat"
`define AUTOTB_TVIN_bias_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_bias.dat"
`define AUTOTB_TVIN_output_r_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_output_r.dat"
`define AUTOTB_TVIN_ci_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_ci.dat"
`define AUTOTB_TVIN_co_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_co.dat"
`define AUTOTB_TVIN_height_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_height.dat"
`define AUTOTB_TVIN_width_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvin_width.dat"
`define AUTOTB_TVOUT_mem  "../tv/cdatafile/c.lung_conv_fp32.autotvout_mem.dat"
`define AUTOTB_TVOUT_ap_return  "../tv/cdatafile/c.lung_conv_fp32.autotvout_ap_return.dat"
`define AUTOTB_TVOUT_mem_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvout_mem.dat"
`define AUTOTB_TVOUT_ap_return_out_wrapc  "../tv/rtldatafile/rtl.lung_conv_fp32.autotvout_ap_return.dat"
module `AUTOTB_TOP;

parameter AUTOTB_TRANSACTION_NUM = 25;
parameter PROGRESS_TIMEOUT = 10000000;
parameter LATENCY_ESTIMATION = -1;
parameter LENGTH_mem = 196864;
parameter LENGTH_input_r = 1;
parameter LENGTH_weight = 1;
parameter LENGTH_bias = 1;
parameter LENGTH_output_r = 1;
parameter LENGTH_ci = 1;
parameter LENGTH_co = 1;
parameter LENGTH_height = 1;
parameter LENGTH_width = 1;
parameter LENGTH_ap_return = 1;

task read_token;
    input integer fp;
    output reg [191 : 0] token;
    integer ret;
    begin
        token = "";
        ret = 0;
        ret = $fscanf(fp,"%s",token);
    end
endtask

reg AESL_clock;
reg rst;
reg dut_rst;
reg start;
reg ce;
reg tb_continue;
wire AESL_start;
wire AESL_reset;
wire AESL_ce;
wire AESL_ready;
wire AESL_idle;
wire AESL_continue;
wire AESL_done;
reg AESL_done_delay = 0;
reg AESL_done_delay2 = 0;
reg AESL_ready_delay = 0;
wire ready;
wire ready_wire;
wire [6 : 0] control_AWADDR;
wire  control_AWVALID;
wire  control_AWREADY;
wire  control_WVALID;
wire  control_WREADY;
wire [31 : 0] control_WDATA;
wire [3 : 0] control_WSTRB;
wire [6 : 0] control_ARADDR;
wire  control_ARVALID;
wire  control_ARREADY;
wire  control_RVALID;
wire  control_RREADY;
wire [31 : 0] control_RDATA;
wire [1 : 0] control_RRESP;
wire  control_BVALID;
wire  control_BREADY;
wire [1 : 0] control_BRESP;
wire  control_INTERRUPT;
wire  mem_AWVALID;
wire  mem_AWREADY;
wire [63 : 0] mem_AWADDR;
wire [0 : 0] mem_AWID;
wire [7 : 0] mem_AWLEN;
wire [2 : 0] mem_AWSIZE;
wire [1 : 0] mem_AWBURST;
wire [1 : 0] mem_AWLOCK;
wire [3 : 0] mem_AWCACHE;
wire [2 : 0] mem_AWPROT;
wire [3 : 0] mem_AWQOS;
wire [3 : 0] mem_AWREGION;
wire [0 : 0] mem_AWUSER;
wire  mem_WVALID;
wire  mem_WREADY;
wire [31 : 0] mem_WDATA;
wire [3 : 0] mem_WSTRB;
wire  mem_WLAST;
wire [0 : 0] mem_WID;
wire [0 : 0] mem_WUSER;
wire  mem_ARVALID;
wire  mem_ARREADY;
wire [63 : 0] mem_ARADDR;
wire [0 : 0] mem_ARID;
wire [7 : 0] mem_ARLEN;
wire [2 : 0] mem_ARSIZE;
wire [1 : 0] mem_ARBURST;
wire [1 : 0] mem_ARLOCK;
wire [3 : 0] mem_ARCACHE;
wire [2 : 0] mem_ARPROT;
wire [3 : 0] mem_ARQOS;
wire [3 : 0] mem_ARREGION;
wire [0 : 0] mem_ARUSER;
wire  mem_RVALID;
wire  mem_RREADY;
wire [31 : 0] mem_RDATA;
wire  mem_RLAST;
wire [0 : 0] mem_RID;
wire [0 : 0] mem_RUSER;
wire [1 : 0] mem_RRESP;
wire  mem_BVALID;
wire  mem_BREADY;
wire [1 : 0] mem_BRESP;
wire [0 : 0] mem_BID;
wire [0 : 0] mem_BUSER;
integer done_cnt = 0;
integer AESL_ready_cnt = 0;
integer ready_cnt = 0;
reg ready_initial;
reg ready_initial_n;
reg ready_last_n;
reg ready_delay_last_n;
reg done_delay_last_n;
reg interface_done = 0;
wire control_read_data_finish;
wire control_write_data_finish;
wire AESL_slave_start;
reg AESL_slave_start_lock = 0;
wire AESL_slave_write_start_in;
wire AESL_slave_write_start_finish;
reg AESL_slave_ready;
wire AESL_slave_output_done;
wire AESL_slave_done;
reg ready_rise = 0;
reg start_rise = 0;
reg slave_start_status = 0;
reg slave_done_status = 0;
reg ap_done_lock = 0;

wire ap_clk;
wire ap_rst_n;
wire ap_rst_n_n;

`AUTOTB_DUT `AUTOTB_DUT_INST(
.s_axi_control_AWADDR(control_AWADDR),
.s_axi_control_AWVALID(control_AWVALID),
.s_axi_control_AWREADY(control_AWREADY),
.s_axi_control_WVALID(control_WVALID),
.s_axi_control_WREADY(control_WREADY),
.s_axi_control_WDATA(control_WDATA),
.s_axi_control_WSTRB(control_WSTRB),
.s_axi_control_ARADDR(control_ARADDR),
.s_axi_control_ARVALID(control_ARVALID),
.s_axi_control_ARREADY(control_ARREADY),
.s_axi_control_RVALID(control_RVALID),
.s_axi_control_RREADY(control_RREADY),
.s_axi_control_RDATA(control_RDATA),
.s_axi_control_RRESP(control_RRESP),
.s_axi_control_BVALID(control_BVALID),
.s_axi_control_BREADY(control_BREADY),
.s_axi_control_BRESP(control_BRESP),
.interrupt(control_INTERRUPT),
.ap_clk(ap_clk),
.ap_rst_n(ap_rst_n),
.m_axi_mem_AWVALID(mem_AWVALID),
.m_axi_mem_AWREADY(mem_AWREADY),
.m_axi_mem_AWADDR(mem_AWADDR),
.m_axi_mem_AWLEN(mem_AWLEN),
.m_axi_mem_AWSIZE(mem_AWSIZE),
.m_axi_mem_AWBURST(mem_AWBURST),
.m_axi_mem_AWLOCK(mem_AWLOCK),
.m_axi_mem_AWCACHE(mem_AWCACHE),
.m_axi_mem_AWPROT(mem_AWPROT),
.m_axi_mem_AWQOS(mem_AWQOS),
.m_axi_mem_AWREGION(mem_AWREGION),
.m_axi_mem_WVALID(mem_WVALID),
.m_axi_mem_WREADY(mem_WREADY),
.m_axi_mem_WDATA(mem_WDATA),
.m_axi_mem_WSTRB(mem_WSTRB),
.m_axi_mem_WLAST(mem_WLAST),
.m_axi_mem_ARVALID(mem_ARVALID),
.m_axi_mem_ARREADY(mem_ARREADY),
.m_axi_mem_ARADDR(mem_ARADDR),
.m_axi_mem_ARLEN(mem_ARLEN),
.m_axi_mem_ARSIZE(mem_ARSIZE),
.m_axi_mem_ARBURST(mem_ARBURST),
.m_axi_mem_ARLOCK(mem_ARLOCK),
.m_axi_mem_ARCACHE(mem_ARCACHE),
.m_axi_mem_ARPROT(mem_ARPROT),
.m_axi_mem_ARQOS(mem_ARQOS),
.m_axi_mem_ARREGION(mem_ARREGION),
.m_axi_mem_RVALID(mem_RVALID),
.m_axi_mem_RREADY(mem_RREADY),
.m_axi_mem_RDATA(mem_RDATA),
.m_axi_mem_RLAST(mem_RLAST),
.m_axi_mem_RRESP(mem_RRESP),
.m_axi_mem_BVALID(mem_BVALID),
.m_axi_mem_BREADY(mem_BREADY),
.m_axi_mem_BRESP(mem_BRESP));
assign mem_AWID = '0;
assign mem_AWUSER = '0;
assign mem_WID = '0;
assign mem_WUSER = '0;
assign mem_ARID = '0;
assign mem_ARUSER = '0;

// Assignment for control signal
assign ap_clk = AESL_clock;
assign ap_rst_n = dut_rst;
assign ap_rst_n_n = ~dut_rst;
assign AESL_reset = rst;
assign AESL_start = start;
assign AESL_ce = ce;
assign AESL_continue = tb_continue;
  assign AESL_slave_write_start_in = slave_start_status  & control_write_data_finish;
  assign AESL_slave_start = AESL_slave_write_start_finish;
  assign AESL_done = slave_done_status  & control_read_data_finish;

always @(posedge AESL_clock)
begin
    if(AESL_reset === 0)
    begin
        slave_start_status <= 1;
    end
    else begin
        if (AESL_start == 1 ) begin
            start_rise = 1;
        end
        if (start_rise == 1 && AESL_done == 1 ) begin
            slave_start_status <= 1;
        end
        if (AESL_slave_write_start_in == 1 && AESL_done == 0) begin 
            slave_start_status <= 0;
            start_rise = 0;
        end
    end
end

always @(posedge AESL_clock)
begin
    if(AESL_reset === 0)
    begin
        AESL_slave_ready <= 0;
        ready_rise = 0;
    end
    else begin
        if (AESL_ready == 1 ) begin
            ready_rise = 1;
        end
        if (ready_rise == 1 && AESL_done_delay == 1 ) begin
            AESL_slave_ready <= 1;
        end
        if (AESL_slave_ready == 1) begin 
            AESL_slave_ready <= 0;
            ready_rise = 0;
        end
    end
end

always @ (posedge AESL_clock)
begin
    if (AESL_done == 1) begin
        slave_done_status <= 0;
    end
    else if (AESL_slave_output_done == 1 ) begin
        slave_done_status <= 1;
    end
end









wire    AESL_axi_master_mem_ready;
wire    AESL_axi_master_mem_done;
AESL_axi_master_mem AESL_AXI_MASTER_mem(
    .clk   (AESL_clock),
    .reset (AESL_reset),
    .TRAN_mem_AWVALID (mem_AWVALID),
    .TRAN_mem_AWREADY (mem_AWREADY),
    .TRAN_mem_AWADDR (mem_AWADDR),
    .TRAN_mem_AWID (mem_AWID),
    .TRAN_mem_AWLEN (mem_AWLEN),
    .TRAN_mem_AWSIZE (mem_AWSIZE),
    .TRAN_mem_AWBURST (mem_AWBURST),
    .TRAN_mem_AWLOCK (mem_AWLOCK),
    .TRAN_mem_AWCACHE (mem_AWCACHE),
    .TRAN_mem_AWPROT (mem_AWPROT),
    .TRAN_mem_AWQOS (mem_AWQOS),
    .TRAN_mem_AWREGION (mem_AWREGION),
    .TRAN_mem_AWUSER (mem_AWUSER),
    .TRAN_mem_WVALID (mem_WVALID),
    .TRAN_mem_WREADY (mem_WREADY),
    .TRAN_mem_WDATA (mem_WDATA),
    .TRAN_mem_WSTRB (mem_WSTRB),
    .TRAN_mem_WLAST (mem_WLAST),
    .TRAN_mem_WID (mem_WID),
    .TRAN_mem_WUSER (mem_WUSER),
    .TRAN_mem_ARVALID (mem_ARVALID),
    .TRAN_mem_ARREADY (mem_ARREADY),
    .TRAN_mem_ARADDR (mem_ARADDR),
    .TRAN_mem_ARID (mem_ARID),
    .TRAN_mem_ARLEN (mem_ARLEN),
    .TRAN_mem_ARSIZE (mem_ARSIZE),
    .TRAN_mem_ARBURST (mem_ARBURST),
    .TRAN_mem_ARLOCK (mem_ARLOCK),
    .TRAN_mem_ARCACHE (mem_ARCACHE),
    .TRAN_mem_ARPROT (mem_ARPROT),
    .TRAN_mem_ARQOS (mem_ARQOS),
    .TRAN_mem_ARREGION (mem_ARREGION),
    .TRAN_mem_ARUSER (mem_ARUSER),
    .TRAN_mem_RVALID (mem_RVALID),
    .TRAN_mem_RREADY (mem_RREADY),
    .TRAN_mem_RDATA (mem_RDATA),
    .TRAN_mem_RLAST (mem_RLAST),
    .TRAN_mem_RID (mem_RID),
    .TRAN_mem_RUSER (mem_RUSER),
    .TRAN_mem_RRESP (mem_RRESP),
    .TRAN_mem_BVALID (mem_BVALID),
    .TRAN_mem_BREADY (mem_BREADY),
    .TRAN_mem_BRESP (mem_BRESP),
    .TRAN_mem_BID (mem_BID),
    .TRAN_mem_BUSER (mem_BUSER),
    .ready (AESL_axi_master_mem_ready),
    .done  (AESL_axi_master_mem_done)
);
assign    AESL_axi_master_mem_ready    =   ready;
assign    AESL_axi_master_mem_done    =   AESL_done_delay;

AESL_axi_slave_control AESL_AXI_SLAVE_control(
    .clk   (AESL_clock),
    .reset (AESL_reset),
    .TRAN_s_axi_control_AWADDR (control_AWADDR),
    .TRAN_s_axi_control_AWVALID (control_AWVALID),
    .TRAN_s_axi_control_AWREADY (control_AWREADY),
    .TRAN_s_axi_control_WVALID (control_WVALID),
    .TRAN_s_axi_control_WREADY (control_WREADY),
    .TRAN_s_axi_control_WDATA (control_WDATA),
    .TRAN_s_axi_control_WSTRB (control_WSTRB),
    .TRAN_s_axi_control_ARADDR (control_ARADDR),
    .TRAN_s_axi_control_ARVALID (control_ARVALID),
    .TRAN_s_axi_control_ARREADY (control_ARREADY),
    .TRAN_s_axi_control_RVALID (control_RVALID),
    .TRAN_s_axi_control_RREADY (control_RREADY),
    .TRAN_s_axi_control_RDATA (control_RDATA),
    .TRAN_s_axi_control_RRESP (control_RRESP),
    .TRAN_s_axi_control_BVALID (control_BVALID),
    .TRAN_s_axi_control_BREADY (control_BREADY),
    .TRAN_s_axi_control_BRESP (control_BRESP),
    .TRAN_control_interrupt (control_INTERRUPT),
    .TRAN_control_read_data_finish(control_read_data_finish),
    .TRAN_control_write_data_finish(control_write_data_finish),
    .TRAN_control_ready_out (AESL_ready),
    .TRAN_control_ready_in (AESL_slave_ready),
    .TRAN_control_done_out (AESL_slave_output_done),
    .TRAN_control_idle_out (AESL_idle),
    .TRAN_control_write_start_in     (AESL_slave_write_start_in),
    .TRAN_control_write_start_finish (AESL_slave_write_start_finish),
    .TRAN_control_transaction_done_in (AESL_done_delay),
    .TRAN_control_start_in  (AESL_slave_start)
);


reg dump_tvout_finish_ap_return;

initial begin : dump_tvout_runtime_sign_ap_return
    integer fp;
    dump_tvout_finish_ap_return = 0;
    fp = $fopen(`AUTOTB_TVOUT_ap_return_out_wrapc, "w");
    if (fp == 0) begin
        $display("Failed to open file \"%s\"!", `AUTOTB_TVOUT_ap_return_out_wrapc);
        $display("ERROR: Simulation using HLS TB failed.");
        $finish;
    end
    $fdisplay(fp,"[[[runtime]]]");
    $fclose(fp);
    wait (done_cnt == AUTOTB_TRANSACTION_NUM);
    // last transaction is saved at negedge right after last done
    repeat(5) @ (posedge AESL_clock);
    fp = $fopen(`AUTOTB_TVOUT_ap_return_out_wrapc, "a");
    if (fp == 0) begin
        $display("Failed to open file \"%s\"!", `AUTOTB_TVOUT_ap_return_out_wrapc);
        $display("ERROR: Simulation using HLS TB failed.");
        $finish;
    end
    $fdisplay(fp,"[[[/runtime]]]");
    $fclose(fp);
    dump_tvout_finish_ap_return = 1;
end

initial begin : generate_AESL_ready_cnt_proc
    AESL_ready_cnt = 0;
    wait(AESL_reset === 1);
    while(AESL_ready_cnt != AUTOTB_TRANSACTION_NUM) begin
        while(AESL_ready !== 1) begin
            @(posedge AESL_clock);
            # 0.4;
        end
        @(negedge AESL_clock);
        AESL_ready_cnt = AESL_ready_cnt + 1;
        @(posedge AESL_clock);
        # 0.4;
    end
end

    event next_trigger_ready_cnt;
    
    initial begin : gen_ready_cnt
        ready_cnt = 0;
        wait (AESL_reset === 1);
        forever begin
            @ (posedge AESL_clock);
            if (ready == 1) begin
                if (ready_cnt < AUTOTB_TRANSACTION_NUM) begin
                    ready_cnt = ready_cnt + 1;
                end
            end
            -> next_trigger_ready_cnt;
        end
    end
    
    wire all_finish = (done_cnt == AUTOTB_TRANSACTION_NUM);
    
    // done_cnt
    always @ (posedge AESL_clock) begin
        if (~AESL_reset) begin
            done_cnt <= 0;
        end else begin
            if (AESL_done == 1) begin
                if (done_cnt < AUTOTB_TRANSACTION_NUM) begin
                    done_cnt <= done_cnt + 1;
                end
            end
        end
    end
    
    initial begin : finish_simulation
        wait (all_finish == 1);
        // last transaction is saved at negedge right after last done
        repeat(6) @ (posedge AESL_clock);
        $finish;
    end
    
initial begin
    AESL_clock = 0;
    forever #`AUTOTB_CLOCK_PERIOD_DIV2 AESL_clock = ~AESL_clock;
end


reg end_mem;
reg [31:0] size_mem;
reg [31:0] size_mem_backup;
reg end_input_r;
reg [31:0] size_input_r;
reg [31:0] size_input_r_backup;
reg end_weight;
reg [31:0] size_weight;
reg [31:0] size_weight_backup;
reg end_bias;
reg [31:0] size_bias;
reg [31:0] size_bias_backup;
reg end_output_r;
reg [31:0] size_output_r;
reg [31:0] size_output_r_backup;
reg end_ci;
reg [31:0] size_ci;
reg [31:0] size_ci_backup;
reg end_co;
reg [31:0] size_co;
reg [31:0] size_co_backup;
reg end_height;
reg [31:0] size_height;
reg [31:0] size_height_backup;
reg end_width;
reg [31:0] size_width;
reg [31:0] size_width_backup;
reg end_ap_return;
reg [31:0] size_ap_return;
reg [31:0] size_ap_return_backup;

initial begin : initial_process
    integer proc_rand;
    rst = 0;
    # 100;
    repeat(0+3) @ (posedge AESL_clock);
    rst = 1;
end
initial begin : initial_process_for_dut_rst
    integer proc_rand;
    dut_rst = 0;
    # 100;
    repeat(3) @ (posedge AESL_clock);
    dut_rst = 1;
end
initial begin : start_process
    integer proc_rand;
    reg [31:0] start_cnt;
    ce = 1;
    start = 0;
    start_cnt = 0;
    wait (AESL_reset === 1);
    @ (posedge AESL_clock);
    #0 start = 1;
    start_cnt = start_cnt + 1;
    forever begin
        if (start_cnt >= AUTOTB_TRANSACTION_NUM + 1) begin
            #0 start = 0;
        end
        @ (posedge AESL_clock);
        if (AESL_ready) begin
            start_cnt = start_cnt + 1;
        end
    end
end

always @(AESL_done)
begin
    tb_continue = AESL_done;
end

initial begin : ready_initial_process
    ready_initial = 0;
    wait (AESL_start === 1);
    ready_initial = 1;
    @(posedge AESL_clock);
    ready_initial = 0;
end

always @(posedge AESL_clock)
begin
    if(AESL_reset === 0)
      AESL_ready_delay = 0;
  else
      AESL_ready_delay = AESL_ready;
end
initial begin : ready_last_n_process
  ready_last_n = 1;
  wait(ready_cnt == AUTOTB_TRANSACTION_NUM)
  @(posedge AESL_clock);
  ready_last_n <= 0;
end

always @(posedge AESL_clock)
begin
    if(AESL_reset === 0)
      ready_delay_last_n = 0;
  else
      ready_delay_last_n <= ready_last_n;
end
assign ready = (ready_initial | AESL_ready_delay);
assign ready_wire = ready_initial | AESL_ready_delay;
initial begin : done_delay_last_n_process
  done_delay_last_n = 1;
  while(done_cnt < AUTOTB_TRANSACTION_NUM)
      @(posedge AESL_clock);
  # 0.1;
  done_delay_last_n = 0;
end

always @(posedge AESL_clock)
begin
    if(AESL_reset === 0)
  begin
      AESL_done_delay <= 0;
      AESL_done_delay2 <= 0;
  end
  else begin
      AESL_done_delay <= AESL_done & done_delay_last_n;
      AESL_done_delay2 <= AESL_done_delay;
  end
end
always @(posedge AESL_clock)
begin
    if(AESL_reset === 0)
      interface_done = 0;
  else begin
      # 0.01;
      if(ready === 1 && ready_cnt > 0 && ready_cnt < AUTOTB_TRANSACTION_NUM)
          interface_done = 1;
      else if(AESL_done_delay === 1 && done_cnt == AUTOTB_TRANSACTION_NUM)
          interface_done = 1;
      else
          interface_done = 0;
  end
end

reg dump_tvout_finish_mem;

initial begin : dump_tvout_runtime_sign_mem
    integer fp;
    dump_tvout_finish_mem = 0;
    fp = $fopen(`AUTOTB_TVOUT_mem_out_wrapc, "w");
    if (fp == 0) begin
        $display("Failed to open file \"%s\"!", `AUTOTB_TVOUT_mem_out_wrapc);
        $display("ERROR: Simulation using HLS TB failed.");
        $finish;
    end
    $fdisplay(fp,"[[[runtime]]]");
    $fclose(fp);
    wait (done_cnt == AUTOTB_TRANSACTION_NUM);
    // last transaction is saved at negedge right after last done
    repeat(5) @ (posedge AESL_clock);
    fp = $fopen(`AUTOTB_TVOUT_mem_out_wrapc, "a");
    if (fp == 0) begin
        $display("Failed to open file \"%s\"!", `AUTOTB_TVOUT_mem_out_wrapc);
        $display("ERROR: Simulation using HLS TB failed.");
        $finish;
    end
    $fdisplay(fp,"[[[/runtime]]]");
    $fclose(fp);
    dump_tvout_finish_mem = 1;
end


////////////////////////////////////////////
// progress and performance
////////////////////////////////////////////

task wait_start();
    while (~AESL_start) begin
        @ (posedge AESL_clock);
    end
endtask

reg [31:0] clk_cnt = 0;
reg AESL_ready_p1;
reg AESL_start_p1;

always @ (posedge AESL_clock) begin
    if (AESL_reset == 0) begin
        clk_cnt <= 32'h0;
        AESL_ready_p1 <= 1'b0;
        AESL_start_p1 <= 1'b0;
    end
    else begin
        clk_cnt <= clk_cnt + 1;
        AESL_ready_p1 <= AESL_ready;
        AESL_start_p1 <= AESL_start;
    end
end

reg [31:0] start_timestamp [0:AUTOTB_TRANSACTION_NUM - 1];
reg [31:0] start_cnt;
reg [31:0] ready_timestamp [0:AUTOTB_TRANSACTION_NUM - 1];
reg [31:0] ap_ready_cnt;
reg [31:0] finish_timestamp [0:AUTOTB_TRANSACTION_NUM - 1];
reg [31:0] finish_cnt;
reg [31:0] lat_total;
event report_progress;

always @(posedge AESL_clock)
begin
    if (finish_cnt == AUTOTB_TRANSACTION_NUM - 1 && AESL_done == 1'b1)
        lat_total = clk_cnt - start_timestamp[0];
end

initial begin
    start_cnt = 0;
    finish_cnt = 0;
    ap_ready_cnt = 0;
    wait (AESL_reset == 1);
    wait_start();
    start_timestamp[start_cnt] = clk_cnt;
    start_cnt = start_cnt + 1;
    if (AESL_done) begin
        finish_timestamp[finish_cnt] = clk_cnt;
        finish_cnt = finish_cnt + 1;
    end
    -> report_progress;
    forever begin
        @ (posedge AESL_clock);
        if (start_cnt < AUTOTB_TRANSACTION_NUM) begin
            if ((AESL_start && AESL_ready_p1)||(AESL_start && ~AESL_start_p1)) begin
                start_timestamp[start_cnt] = clk_cnt;
                start_cnt = start_cnt + 1;
            end
        end
        if (ap_ready_cnt < AUTOTB_TRANSACTION_NUM) begin
            if (AESL_start_p1 && AESL_ready_p1) begin
                ready_timestamp[ap_ready_cnt] = clk_cnt;
                ap_ready_cnt = ap_ready_cnt + 1;
            end
        end
        if (finish_cnt < AUTOTB_TRANSACTION_NUM) begin
            if (AESL_done) begin
                finish_timestamp[finish_cnt] = clk_cnt;
                finish_cnt = finish_cnt + 1;
            end
        end
        -> report_progress;
    end
end

reg [31:0] progress_timeout;

initial begin : simulation_progress
    real intra_progress;
    wait (AESL_reset == 1);
    progress_timeout = PROGRESS_TIMEOUT;
    $display("////////////////////////////////////////////////////////////////////////////////////");
    $display("// Inter-Transaction Progress: Completed Transaction / Total Transaction");
    $display("// Intra-Transaction Progress: Measured Latency / Latency Estimation * 100%%");
    $display("//");
    $display("// RTL Simulation : \"Inter-Transaction Progress\" [\"Intra-Transaction Progress\"] @ \"Simulation Time\"");
    $display("////////////////////////////////////////////////////////////////////////////////////");
    print_progress();
    while (finish_cnt < AUTOTB_TRANSACTION_NUM) begin
        @ (report_progress);
        if (finish_cnt < AUTOTB_TRANSACTION_NUM) begin
            if (AESL_done) begin
                print_progress();
                progress_timeout = PROGRESS_TIMEOUT;
            end else begin
                if (progress_timeout == 0) begin
                    print_progress();
                    progress_timeout = PROGRESS_TIMEOUT;
                end else begin
                    progress_timeout = progress_timeout - 1;
                end
            end
        end
    end
    print_progress();
    $display("////////////////////////////////////////////////////////////////////////////////////");
    calculate_performance();
end

task get_intra_progress(output real intra_progress);
    begin
        if (start_cnt > finish_cnt) begin
            intra_progress = clk_cnt - start_timestamp[finish_cnt];
        end else if(finish_cnt > 0) begin
            intra_progress = LATENCY_ESTIMATION;
        end else begin
            intra_progress = 0;
        end
        intra_progress = intra_progress / LATENCY_ESTIMATION;
    end
endtask

task print_progress();
    real intra_progress;
    begin
        if (LATENCY_ESTIMATION > 0) begin
            get_intra_progress(intra_progress);
            $display("// RTL Simulation : %0d / %0d [%2.2f%%] @ \"%0t\"", finish_cnt, AUTOTB_TRANSACTION_NUM, intra_progress * 100, $time);
        end else begin
            $display("// RTL Simulation : %0d / %0d [n/a] @ \"%0t\"", finish_cnt, AUTOTB_TRANSACTION_NUM, $time);
        end
    end
endtask

task calculate_performance();
    integer i;
    integer fp;
    reg [31:0] latency [0:AUTOTB_TRANSACTION_NUM - 1];
    reg [31:0] latency_min;
    reg [31:0] latency_max;
    reg [31:0] latency_total;
    reg [31:0] latency_average;
    reg [31:0] interval [0:AUTOTB_TRANSACTION_NUM - 2];
    reg [31:0] interval_min;
    reg [31:0] interval_max;
    reg [31:0] interval_total;
    reg [31:0] interval_average;
    reg [31:0] total_execute_time;
    begin
        latency_min = -1;
        latency_max = 0;
        latency_total = 0;
        interval_min = -1;
        interval_max = 0;
        interval_total = 0;
        total_execute_time = lat_total;

        for (i = 0; i < AUTOTB_TRANSACTION_NUM; i = i + 1) begin
            // calculate latency
            latency[i] = finish_timestamp[i] - start_timestamp[i];
            if (latency[i] > latency_max) latency_max = latency[i];
            if (latency[i] < latency_min) latency_min = latency[i];
            latency_total = latency_total + latency[i];
            // calculate interval
            if (AUTOTB_TRANSACTION_NUM == 1) begin
                interval[i] = 0;
                interval_max = 0;
                interval_min = 0;
                interval_total = 0;
            end else if (i < AUTOTB_TRANSACTION_NUM - 1) begin
                interval[i] = start_timestamp[i + 1] - start_timestamp[i];
                if (interval[i] > interval_max) interval_max = interval[i];
                if (interval[i] < interval_min) interval_min = interval[i];
                interval_total = interval_total + interval[i];
            end
        end

        latency_average = latency_total / AUTOTB_TRANSACTION_NUM;
        if (AUTOTB_TRANSACTION_NUM == 1) begin
            interval_average = 0;
        end else begin
            interval_average = interval_total / (AUTOTB_TRANSACTION_NUM - 1);
        end

        fp = $fopen(`AUTOTB_LAT_RESULT_FILE, "w");

        $fdisplay(fp, "$MAX_LATENCY = \"%0d\"", latency_max);
        $fdisplay(fp, "$MIN_LATENCY = \"%0d\"", latency_min);
        $fdisplay(fp, "$AVER_LATENCY = \"%0d\"", latency_average);
        $fdisplay(fp, "$MAX_THROUGHPUT = \"%0d\"", interval_max);
        $fdisplay(fp, "$MIN_THROUGHPUT = \"%0d\"", interval_min);
        $fdisplay(fp, "$AVER_THROUGHPUT = \"%0d\"", interval_average);
        $fdisplay(fp, "$TOTAL_EXECUTE_TIME = \"%0d\"", total_execute_time);

        $fclose(fp);

        fp = $fopen(`AUTOTB_PER_RESULT_TRANS_FILE, "w");

        $fdisplay(fp, "%20s%16s%16s", "", "latency", "interval");
        if (AUTOTB_TRANSACTION_NUM == 1) begin
            i = 0;
            $fdisplay(fp, "transaction%8d:%16d%16d", i, latency[i], interval[i]);
        end else begin
            for (i = 0; i < AUTOTB_TRANSACTION_NUM; i = i + 1) begin
                if (i < AUTOTB_TRANSACTION_NUM - 1) begin
                    $fdisplay(fp, "transaction%8d:%16d%16d", i, latency[i], interval[i]);
                end else begin
                    $fdisplay(fp, "transaction%8d:%16d               x", i, latency[i]);
                end
            end
        end

        $fclose(fp);
    end
endtask


////////////////////////////////////////////
// Dependence Check
////////////////////////////////////////////

`ifndef POST_SYN

// Dependence Check (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_0_to [13 - 1:0];
time DEP_time_0_to [13 - 1:0];
reg [4:0] DEP_address_0_from [1 - 1:0];
time DEP_time_0_from [1 - 1:0];
reg DEP_error_0 = 0;
integer DEP_i_0;

initial begin
    DEP_address_0_to[0] = 0;
    DEP_time_0_to[0] = 0;
    DEP_address_0_to[1] = 0;
    DEP_time_0_to[1] = 0;
    DEP_address_0_to[2] = 0;
    DEP_time_0_to[2] = 0;
    DEP_address_0_to[3] = 0;
    DEP_time_0_to[3] = 0;
    DEP_address_0_to[4] = 0;
    DEP_time_0_to[4] = 0;
    DEP_address_0_to[5] = 0;
    DEP_time_0_to[5] = 0;
    DEP_address_0_to[6] = 0;
    DEP_time_0_to[6] = 0;
    DEP_address_0_to[7] = 0;
    DEP_time_0_to[7] = 0;
    DEP_address_0_to[8] = 0;
    DEP_time_0_to[8] = 0;
    DEP_address_0_to[9] = 0;
    DEP_time_0_to[9] = 0;
    DEP_address_0_to[10] = 0;
    DEP_time_0_to[10] = 0;
    DEP_address_0_to[11] = 0;
    DEP_time_0_to[11] = 0;
    DEP_address_0_to[12] = 0;
    DEP_time_0_to[12] = 0;
    DEP_address_0_from[0] = 0;
    DEP_time_0_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_0_to[12] = DEP_address_0_to[11];
            DEP_time_0_to[12] = DEP_time_0_to[11];
            DEP_address_0_to[11] = DEP_address_0_to[10];
            DEP_time_0_to[11] = DEP_time_0_to[10];
            DEP_address_0_to[10] = DEP_address_0_to[9];
            DEP_time_0_to[10] = DEP_time_0_to[9];
            DEP_address_0_to[9] = DEP_address_0_to[8];
            DEP_time_0_to[9] = DEP_time_0_to[8];
            DEP_address_0_to[8] = DEP_address_0_to[7];
            DEP_time_0_to[8] = DEP_time_0_to[7];
            DEP_address_0_to[7] = DEP_address_0_to[6];
            DEP_time_0_to[7] = DEP_time_0_to[6];
            DEP_address_0_to[6] = DEP_address_0_to[5];
            DEP_time_0_to[6] = DEP_time_0_to[5];
            DEP_address_0_to[5] = DEP_address_0_to[4];
            DEP_time_0_to[5] = DEP_time_0_to[4];
            DEP_address_0_to[4] = DEP_address_0_to[3];
            DEP_time_0_to[4] = DEP_time_0_to[3];
            DEP_address_0_to[3] = DEP_address_0_to[2];
            DEP_time_0_to[3] = DEP_time_0_to[2];
            DEP_address_0_to[2] = DEP_address_0_to[1];
            DEP_time_0_to[2] = DEP_time_0_to[1];
            DEP_address_0_to[1] = DEP_address_0_to[0];
            DEP_time_0_to[1] = DEP_time_0_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1127) begin
                DEP_address_0_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_0_address0};
                DEP_time_0_to[0] = $time;
            end else begin
                DEP_address_0_to[0] = {1'b0, 4'b0};
                DEP_time_0_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_0_to[12] = DEP_address_0_to[11];
            DEP_time_0_to[12] = DEP_time_0_to[11];
            DEP_address_0_to[11] = DEP_address_0_to[10];
            DEP_time_0_to[11] = DEP_time_0_to[10];
            DEP_address_0_to[10] = DEP_address_0_to[9];
            DEP_time_0_to[10] = DEP_time_0_to[9];
            DEP_address_0_to[9] = DEP_address_0_to[8];
            DEP_time_0_to[9] = DEP_time_0_to[8];
            DEP_address_0_to[8] = DEP_address_0_to[7];
            DEP_time_0_to[8] = DEP_time_0_to[7];
            DEP_address_0_to[7] = DEP_address_0_to[6];
            DEP_time_0_to[7] = DEP_time_0_to[6];
            DEP_address_0_to[6] = DEP_address_0_to[5];
            DEP_time_0_to[6] = DEP_time_0_to[5];
            DEP_address_0_to[5] = DEP_address_0_to[4];
            DEP_time_0_to[5] = DEP_time_0_to[4];
            DEP_address_0_to[4] = DEP_address_0_to[3];
            DEP_time_0_to[4] = DEP_time_0_to[3];
            DEP_address_0_to[3] = DEP_address_0_to[2];
            DEP_time_0_to[3] = DEP_time_0_to[2];
            DEP_address_0_to[2] = DEP_address_0_to[1];
            DEP_time_0_to[2] = DEP_time_0_to[1];
            DEP_address_0_to[1] = DEP_address_0_to[0];
            DEP_time_0_to[1] = DEP_time_0_to[0];
            DEP_address_0_to[0] = {1'b0, 4'b0};
            DEP_time_0_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1327) begin
                if (DEP_address_0_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_0_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_0_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_0_address1};
                DEP_time_0_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1327) begin
                DEP_i_0 = 0;
                if (DEP_address_0_to[0][4]) begin
                    DEP_error_0 = (DEP_address_0_to[0][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[0][3:0], DEP_time_0_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[1][4]) begin
                    DEP_error_0 = (DEP_address_0_to[1][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[1][3:0], DEP_time_0_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[2][4]) begin
                    DEP_error_0 = (DEP_address_0_to[2][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[2][3:0], DEP_time_0_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[3][4]) begin
                    DEP_error_0 = (DEP_address_0_to[3][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[3][3:0], DEP_time_0_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[4][4]) begin
                    DEP_error_0 = (DEP_address_0_to[4][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[4][3:0], DEP_time_0_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[5][4]) begin
                    DEP_error_0 = (DEP_address_0_to[5][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[5][3:0], DEP_time_0_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[6][4]) begin
                    DEP_error_0 = (DEP_address_0_to[6][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[6][3:0], DEP_time_0_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[7][4]) begin
                    DEP_error_0 = (DEP_address_0_to[7][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[7][3:0], DEP_time_0_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[8][4]) begin
                    DEP_error_0 = (DEP_address_0_to[8][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[8][3:0], DEP_time_0_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[9][4]) begin
                    DEP_error_0 = (DEP_address_0_to[9][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[9][3:0], DEP_time_0_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[10][4]) begin
                    DEP_error_0 = (DEP_address_0_to[10][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[10][3:0], DEP_time_0_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[11][4]) begin
                    DEP_error_0 = (DEP_address_0_to[11][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[11][3:0], DEP_time_0_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_0_to[12][4]) begin
                    DEP_error_0 = (DEP_address_0_to[12][3:0] == DEP_address_0_from[DEP_i_0][3:0]);
                    if (DEP_error_0) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_0_address1\" = 0x%0h @ \"%0t\"", DEP_address_0_from[DEP_i_0][3:0], DEP_time_0_from[DEP_i_0]);
                        $display("//                : To memory access \"acc_0_address0\" = DEP_address_0_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_0_to[12][3:0], DEP_time_0_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1327"(W:SV18-18) -> "ap_enable_operation_1127"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_0_from[DEP_i_0] = {1'b0, 4'b0};
                DEP_time_0_from[DEP_i_0] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_1_to [13 - 1:0];
time DEP_time_1_to [13 - 1:0];
reg [4:0] DEP_address_1_from [1 - 1:0];
time DEP_time_1_from [1 - 1:0];
reg DEP_error_1 = 0;
integer DEP_i_1;

initial begin
    DEP_address_1_to[0] = 0;
    DEP_time_1_to[0] = 0;
    DEP_address_1_to[1] = 0;
    DEP_time_1_to[1] = 0;
    DEP_address_1_to[2] = 0;
    DEP_time_1_to[2] = 0;
    DEP_address_1_to[3] = 0;
    DEP_time_1_to[3] = 0;
    DEP_address_1_to[4] = 0;
    DEP_time_1_to[4] = 0;
    DEP_address_1_to[5] = 0;
    DEP_time_1_to[5] = 0;
    DEP_address_1_to[6] = 0;
    DEP_time_1_to[6] = 0;
    DEP_address_1_to[7] = 0;
    DEP_time_1_to[7] = 0;
    DEP_address_1_to[8] = 0;
    DEP_time_1_to[8] = 0;
    DEP_address_1_to[9] = 0;
    DEP_time_1_to[9] = 0;
    DEP_address_1_to[10] = 0;
    DEP_time_1_to[10] = 0;
    DEP_address_1_to[11] = 0;
    DEP_time_1_to[11] = 0;
    DEP_address_1_to[12] = 0;
    DEP_time_1_to[12] = 0;
    DEP_address_1_from[0] = 0;
    DEP_time_1_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_1_to[12] = DEP_address_1_to[11];
            DEP_time_1_to[12] = DEP_time_1_to[11];
            DEP_address_1_to[11] = DEP_address_1_to[10];
            DEP_time_1_to[11] = DEP_time_1_to[10];
            DEP_address_1_to[10] = DEP_address_1_to[9];
            DEP_time_1_to[10] = DEP_time_1_to[9];
            DEP_address_1_to[9] = DEP_address_1_to[8];
            DEP_time_1_to[9] = DEP_time_1_to[8];
            DEP_address_1_to[8] = DEP_address_1_to[7];
            DEP_time_1_to[8] = DEP_time_1_to[7];
            DEP_address_1_to[7] = DEP_address_1_to[6];
            DEP_time_1_to[7] = DEP_time_1_to[6];
            DEP_address_1_to[6] = DEP_address_1_to[5];
            DEP_time_1_to[6] = DEP_time_1_to[5];
            DEP_address_1_to[5] = DEP_address_1_to[4];
            DEP_time_1_to[5] = DEP_time_1_to[4];
            DEP_address_1_to[4] = DEP_address_1_to[3];
            DEP_time_1_to[4] = DEP_time_1_to[3];
            DEP_address_1_to[3] = DEP_address_1_to[2];
            DEP_time_1_to[3] = DEP_time_1_to[2];
            DEP_address_1_to[2] = DEP_address_1_to[1];
            DEP_time_1_to[2] = DEP_time_1_to[1];
            DEP_address_1_to[1] = DEP_address_1_to[0];
            DEP_time_1_to[1] = DEP_time_1_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1129) begin
                DEP_address_1_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_1_address0};
                DEP_time_1_to[0] = $time;
            end else begin
                DEP_address_1_to[0] = {1'b0, 4'b0};
                DEP_time_1_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_1_to[12] = DEP_address_1_to[11];
            DEP_time_1_to[12] = DEP_time_1_to[11];
            DEP_address_1_to[11] = DEP_address_1_to[10];
            DEP_time_1_to[11] = DEP_time_1_to[10];
            DEP_address_1_to[10] = DEP_address_1_to[9];
            DEP_time_1_to[10] = DEP_time_1_to[9];
            DEP_address_1_to[9] = DEP_address_1_to[8];
            DEP_time_1_to[9] = DEP_time_1_to[8];
            DEP_address_1_to[8] = DEP_address_1_to[7];
            DEP_time_1_to[8] = DEP_time_1_to[7];
            DEP_address_1_to[7] = DEP_address_1_to[6];
            DEP_time_1_to[7] = DEP_time_1_to[6];
            DEP_address_1_to[6] = DEP_address_1_to[5];
            DEP_time_1_to[6] = DEP_time_1_to[5];
            DEP_address_1_to[5] = DEP_address_1_to[4];
            DEP_time_1_to[5] = DEP_time_1_to[4];
            DEP_address_1_to[4] = DEP_address_1_to[3];
            DEP_time_1_to[4] = DEP_time_1_to[3];
            DEP_address_1_to[3] = DEP_address_1_to[2];
            DEP_time_1_to[3] = DEP_time_1_to[2];
            DEP_address_1_to[2] = DEP_address_1_to[1];
            DEP_time_1_to[2] = DEP_time_1_to[1];
            DEP_address_1_to[1] = DEP_address_1_to[0];
            DEP_time_1_to[1] = DEP_time_1_to[0];
            DEP_address_1_to[0] = {1'b0, 4'b0};
            DEP_time_1_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1329) begin
                if (DEP_address_1_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_1_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_1_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_1_address1};
                DEP_time_1_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1329) begin
                DEP_i_1 = 0;
                if (DEP_address_1_to[0][4]) begin
                    DEP_error_1 = (DEP_address_1_to[0][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[0][3:0], DEP_time_1_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[1][4]) begin
                    DEP_error_1 = (DEP_address_1_to[1][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[1][3:0], DEP_time_1_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[2][4]) begin
                    DEP_error_1 = (DEP_address_1_to[2][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[2][3:0], DEP_time_1_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[3][4]) begin
                    DEP_error_1 = (DEP_address_1_to[3][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[3][3:0], DEP_time_1_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[4][4]) begin
                    DEP_error_1 = (DEP_address_1_to[4][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[4][3:0], DEP_time_1_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[5][4]) begin
                    DEP_error_1 = (DEP_address_1_to[5][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[5][3:0], DEP_time_1_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[6][4]) begin
                    DEP_error_1 = (DEP_address_1_to[6][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[6][3:0], DEP_time_1_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[7][4]) begin
                    DEP_error_1 = (DEP_address_1_to[7][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[7][3:0], DEP_time_1_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[8][4]) begin
                    DEP_error_1 = (DEP_address_1_to[8][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[8][3:0], DEP_time_1_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[9][4]) begin
                    DEP_error_1 = (DEP_address_1_to[9][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[9][3:0], DEP_time_1_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[10][4]) begin
                    DEP_error_1 = (DEP_address_1_to[10][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[10][3:0], DEP_time_1_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[11][4]) begin
                    DEP_error_1 = (DEP_address_1_to[11][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[11][3:0], DEP_time_1_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_1_to[12][4]) begin
                    DEP_error_1 = (DEP_address_1_to[12][3:0] == DEP_address_1_from[DEP_i_1][3:0]);
                    if (DEP_error_1) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_1_address1\" = 0x%0h @ \"%0t\"", DEP_address_1_from[DEP_i_1][3:0], DEP_time_1_from[DEP_i_1]);
                        $display("//                : To memory access \"acc_1_address0\" = DEP_address_1_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_1_to[12][3:0], DEP_time_1_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1329"(W:SV18-18) -> "ap_enable_operation_1129"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_1_from[DEP_i_1] = {1'b0, 4'b0};
                DEP_time_1_from[DEP_i_1] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_2_to [13 - 1:0];
time DEP_time_2_to [13 - 1:0];
reg [4:0] DEP_address_2_from [1 - 1:0];
time DEP_time_2_from [1 - 1:0];
reg DEP_error_2 = 0;
integer DEP_i_2;

initial begin
    DEP_address_2_to[0] = 0;
    DEP_time_2_to[0] = 0;
    DEP_address_2_to[1] = 0;
    DEP_time_2_to[1] = 0;
    DEP_address_2_to[2] = 0;
    DEP_time_2_to[2] = 0;
    DEP_address_2_to[3] = 0;
    DEP_time_2_to[3] = 0;
    DEP_address_2_to[4] = 0;
    DEP_time_2_to[4] = 0;
    DEP_address_2_to[5] = 0;
    DEP_time_2_to[5] = 0;
    DEP_address_2_to[6] = 0;
    DEP_time_2_to[6] = 0;
    DEP_address_2_to[7] = 0;
    DEP_time_2_to[7] = 0;
    DEP_address_2_to[8] = 0;
    DEP_time_2_to[8] = 0;
    DEP_address_2_to[9] = 0;
    DEP_time_2_to[9] = 0;
    DEP_address_2_to[10] = 0;
    DEP_time_2_to[10] = 0;
    DEP_address_2_to[11] = 0;
    DEP_time_2_to[11] = 0;
    DEP_address_2_to[12] = 0;
    DEP_time_2_to[12] = 0;
    DEP_address_2_from[0] = 0;
    DEP_time_2_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_2_to[12] = DEP_address_2_to[11];
            DEP_time_2_to[12] = DEP_time_2_to[11];
            DEP_address_2_to[11] = DEP_address_2_to[10];
            DEP_time_2_to[11] = DEP_time_2_to[10];
            DEP_address_2_to[10] = DEP_address_2_to[9];
            DEP_time_2_to[10] = DEP_time_2_to[9];
            DEP_address_2_to[9] = DEP_address_2_to[8];
            DEP_time_2_to[9] = DEP_time_2_to[8];
            DEP_address_2_to[8] = DEP_address_2_to[7];
            DEP_time_2_to[8] = DEP_time_2_to[7];
            DEP_address_2_to[7] = DEP_address_2_to[6];
            DEP_time_2_to[7] = DEP_time_2_to[6];
            DEP_address_2_to[6] = DEP_address_2_to[5];
            DEP_time_2_to[6] = DEP_time_2_to[5];
            DEP_address_2_to[5] = DEP_address_2_to[4];
            DEP_time_2_to[5] = DEP_time_2_to[4];
            DEP_address_2_to[4] = DEP_address_2_to[3];
            DEP_time_2_to[4] = DEP_time_2_to[3];
            DEP_address_2_to[3] = DEP_address_2_to[2];
            DEP_time_2_to[3] = DEP_time_2_to[2];
            DEP_address_2_to[2] = DEP_address_2_to[1];
            DEP_time_2_to[2] = DEP_time_2_to[1];
            DEP_address_2_to[1] = DEP_address_2_to[0];
            DEP_time_2_to[1] = DEP_time_2_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1131) begin
                DEP_address_2_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_2_address0};
                DEP_time_2_to[0] = $time;
            end else begin
                DEP_address_2_to[0] = {1'b0, 4'b0};
                DEP_time_2_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_2_to[12] = DEP_address_2_to[11];
            DEP_time_2_to[12] = DEP_time_2_to[11];
            DEP_address_2_to[11] = DEP_address_2_to[10];
            DEP_time_2_to[11] = DEP_time_2_to[10];
            DEP_address_2_to[10] = DEP_address_2_to[9];
            DEP_time_2_to[10] = DEP_time_2_to[9];
            DEP_address_2_to[9] = DEP_address_2_to[8];
            DEP_time_2_to[9] = DEP_time_2_to[8];
            DEP_address_2_to[8] = DEP_address_2_to[7];
            DEP_time_2_to[8] = DEP_time_2_to[7];
            DEP_address_2_to[7] = DEP_address_2_to[6];
            DEP_time_2_to[7] = DEP_time_2_to[6];
            DEP_address_2_to[6] = DEP_address_2_to[5];
            DEP_time_2_to[6] = DEP_time_2_to[5];
            DEP_address_2_to[5] = DEP_address_2_to[4];
            DEP_time_2_to[5] = DEP_time_2_to[4];
            DEP_address_2_to[4] = DEP_address_2_to[3];
            DEP_time_2_to[4] = DEP_time_2_to[3];
            DEP_address_2_to[3] = DEP_address_2_to[2];
            DEP_time_2_to[3] = DEP_time_2_to[2];
            DEP_address_2_to[2] = DEP_address_2_to[1];
            DEP_time_2_to[2] = DEP_time_2_to[1];
            DEP_address_2_to[1] = DEP_address_2_to[0];
            DEP_time_2_to[1] = DEP_time_2_to[0];
            DEP_address_2_to[0] = {1'b0, 4'b0};
            DEP_time_2_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1331) begin
                if (DEP_address_2_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_2_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_2_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_2_address1};
                DEP_time_2_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1331) begin
                DEP_i_2 = 0;
                if (DEP_address_2_to[0][4]) begin
                    DEP_error_2 = (DEP_address_2_to[0][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[0][3:0], DEP_time_2_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[1][4]) begin
                    DEP_error_2 = (DEP_address_2_to[1][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[1][3:0], DEP_time_2_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[2][4]) begin
                    DEP_error_2 = (DEP_address_2_to[2][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[2][3:0], DEP_time_2_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[3][4]) begin
                    DEP_error_2 = (DEP_address_2_to[3][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[3][3:0], DEP_time_2_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[4][4]) begin
                    DEP_error_2 = (DEP_address_2_to[4][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[4][3:0], DEP_time_2_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[5][4]) begin
                    DEP_error_2 = (DEP_address_2_to[5][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[5][3:0], DEP_time_2_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[6][4]) begin
                    DEP_error_2 = (DEP_address_2_to[6][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[6][3:0], DEP_time_2_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[7][4]) begin
                    DEP_error_2 = (DEP_address_2_to[7][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[7][3:0], DEP_time_2_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[8][4]) begin
                    DEP_error_2 = (DEP_address_2_to[8][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[8][3:0], DEP_time_2_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[9][4]) begin
                    DEP_error_2 = (DEP_address_2_to[9][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[9][3:0], DEP_time_2_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[10][4]) begin
                    DEP_error_2 = (DEP_address_2_to[10][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[10][3:0], DEP_time_2_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[11][4]) begin
                    DEP_error_2 = (DEP_address_2_to[11][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[11][3:0], DEP_time_2_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_2_to[12][4]) begin
                    DEP_error_2 = (DEP_address_2_to[12][3:0] == DEP_address_2_from[DEP_i_2][3:0]);
                    if (DEP_error_2) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_2_address1\" = 0x%0h @ \"%0t\"", DEP_address_2_from[DEP_i_2][3:0], DEP_time_2_from[DEP_i_2]);
                        $display("//                : To memory access \"acc_2_address0\" = DEP_address_2_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_2_to[12][3:0], DEP_time_2_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1331"(W:SV18-18) -> "ap_enable_operation_1131"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_2_from[DEP_i_2] = {1'b0, 4'b0};
                DEP_time_2_from[DEP_i_2] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_3_to [13 - 1:0];
time DEP_time_3_to [13 - 1:0];
reg [4:0] DEP_address_3_from [1 - 1:0];
time DEP_time_3_from [1 - 1:0];
reg DEP_error_3 = 0;
integer DEP_i_3;

initial begin
    DEP_address_3_to[0] = 0;
    DEP_time_3_to[0] = 0;
    DEP_address_3_to[1] = 0;
    DEP_time_3_to[1] = 0;
    DEP_address_3_to[2] = 0;
    DEP_time_3_to[2] = 0;
    DEP_address_3_to[3] = 0;
    DEP_time_3_to[3] = 0;
    DEP_address_3_to[4] = 0;
    DEP_time_3_to[4] = 0;
    DEP_address_3_to[5] = 0;
    DEP_time_3_to[5] = 0;
    DEP_address_3_to[6] = 0;
    DEP_time_3_to[6] = 0;
    DEP_address_3_to[7] = 0;
    DEP_time_3_to[7] = 0;
    DEP_address_3_to[8] = 0;
    DEP_time_3_to[8] = 0;
    DEP_address_3_to[9] = 0;
    DEP_time_3_to[9] = 0;
    DEP_address_3_to[10] = 0;
    DEP_time_3_to[10] = 0;
    DEP_address_3_to[11] = 0;
    DEP_time_3_to[11] = 0;
    DEP_address_3_to[12] = 0;
    DEP_time_3_to[12] = 0;
    DEP_address_3_from[0] = 0;
    DEP_time_3_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_3_to[12] = DEP_address_3_to[11];
            DEP_time_3_to[12] = DEP_time_3_to[11];
            DEP_address_3_to[11] = DEP_address_3_to[10];
            DEP_time_3_to[11] = DEP_time_3_to[10];
            DEP_address_3_to[10] = DEP_address_3_to[9];
            DEP_time_3_to[10] = DEP_time_3_to[9];
            DEP_address_3_to[9] = DEP_address_3_to[8];
            DEP_time_3_to[9] = DEP_time_3_to[8];
            DEP_address_3_to[8] = DEP_address_3_to[7];
            DEP_time_3_to[8] = DEP_time_3_to[7];
            DEP_address_3_to[7] = DEP_address_3_to[6];
            DEP_time_3_to[7] = DEP_time_3_to[6];
            DEP_address_3_to[6] = DEP_address_3_to[5];
            DEP_time_3_to[6] = DEP_time_3_to[5];
            DEP_address_3_to[5] = DEP_address_3_to[4];
            DEP_time_3_to[5] = DEP_time_3_to[4];
            DEP_address_3_to[4] = DEP_address_3_to[3];
            DEP_time_3_to[4] = DEP_time_3_to[3];
            DEP_address_3_to[3] = DEP_address_3_to[2];
            DEP_time_3_to[3] = DEP_time_3_to[2];
            DEP_address_3_to[2] = DEP_address_3_to[1];
            DEP_time_3_to[2] = DEP_time_3_to[1];
            DEP_address_3_to[1] = DEP_address_3_to[0];
            DEP_time_3_to[1] = DEP_time_3_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1133) begin
                DEP_address_3_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_3_address0};
                DEP_time_3_to[0] = $time;
            end else begin
                DEP_address_3_to[0] = {1'b0, 4'b0};
                DEP_time_3_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_3_to[12] = DEP_address_3_to[11];
            DEP_time_3_to[12] = DEP_time_3_to[11];
            DEP_address_3_to[11] = DEP_address_3_to[10];
            DEP_time_3_to[11] = DEP_time_3_to[10];
            DEP_address_3_to[10] = DEP_address_3_to[9];
            DEP_time_3_to[10] = DEP_time_3_to[9];
            DEP_address_3_to[9] = DEP_address_3_to[8];
            DEP_time_3_to[9] = DEP_time_3_to[8];
            DEP_address_3_to[8] = DEP_address_3_to[7];
            DEP_time_3_to[8] = DEP_time_3_to[7];
            DEP_address_3_to[7] = DEP_address_3_to[6];
            DEP_time_3_to[7] = DEP_time_3_to[6];
            DEP_address_3_to[6] = DEP_address_3_to[5];
            DEP_time_3_to[6] = DEP_time_3_to[5];
            DEP_address_3_to[5] = DEP_address_3_to[4];
            DEP_time_3_to[5] = DEP_time_3_to[4];
            DEP_address_3_to[4] = DEP_address_3_to[3];
            DEP_time_3_to[4] = DEP_time_3_to[3];
            DEP_address_3_to[3] = DEP_address_3_to[2];
            DEP_time_3_to[3] = DEP_time_3_to[2];
            DEP_address_3_to[2] = DEP_address_3_to[1];
            DEP_time_3_to[2] = DEP_time_3_to[1];
            DEP_address_3_to[1] = DEP_address_3_to[0];
            DEP_time_3_to[1] = DEP_time_3_to[0];
            DEP_address_3_to[0] = {1'b0, 4'b0};
            DEP_time_3_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1333) begin
                if (DEP_address_3_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_3_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_3_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_3_address1};
                DEP_time_3_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1333) begin
                DEP_i_3 = 0;
                if (DEP_address_3_to[0][4]) begin
                    DEP_error_3 = (DEP_address_3_to[0][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[0][3:0], DEP_time_3_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[1][4]) begin
                    DEP_error_3 = (DEP_address_3_to[1][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[1][3:0], DEP_time_3_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[2][4]) begin
                    DEP_error_3 = (DEP_address_3_to[2][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[2][3:0], DEP_time_3_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[3][4]) begin
                    DEP_error_3 = (DEP_address_3_to[3][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[3][3:0], DEP_time_3_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[4][4]) begin
                    DEP_error_3 = (DEP_address_3_to[4][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[4][3:0], DEP_time_3_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[5][4]) begin
                    DEP_error_3 = (DEP_address_3_to[5][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[5][3:0], DEP_time_3_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[6][4]) begin
                    DEP_error_3 = (DEP_address_3_to[6][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[6][3:0], DEP_time_3_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[7][4]) begin
                    DEP_error_3 = (DEP_address_3_to[7][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[7][3:0], DEP_time_3_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[8][4]) begin
                    DEP_error_3 = (DEP_address_3_to[8][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[8][3:0], DEP_time_3_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[9][4]) begin
                    DEP_error_3 = (DEP_address_3_to[9][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[9][3:0], DEP_time_3_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[10][4]) begin
                    DEP_error_3 = (DEP_address_3_to[10][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[10][3:0], DEP_time_3_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[11][4]) begin
                    DEP_error_3 = (DEP_address_3_to[11][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[11][3:0], DEP_time_3_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_3_to[12][4]) begin
                    DEP_error_3 = (DEP_address_3_to[12][3:0] == DEP_address_3_from[DEP_i_3][3:0]);
                    if (DEP_error_3) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_3_address1\" = 0x%0h @ \"%0t\"", DEP_address_3_from[DEP_i_3][3:0], DEP_time_3_from[DEP_i_3]);
                        $display("//                : To memory access \"acc_3_address0\" = DEP_address_3_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_3_to[12][3:0], DEP_time_3_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1333"(W:SV18-18) -> "ap_enable_operation_1133"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_3_from[DEP_i_3] = {1'b0, 4'b0};
                DEP_time_3_from[DEP_i_3] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_4_to [13 - 1:0];
time DEP_time_4_to [13 - 1:0];
reg [4:0] DEP_address_4_from [1 - 1:0];
time DEP_time_4_from [1 - 1:0];
reg DEP_error_4 = 0;
integer DEP_i_4;

initial begin
    DEP_address_4_to[0] = 0;
    DEP_time_4_to[0] = 0;
    DEP_address_4_to[1] = 0;
    DEP_time_4_to[1] = 0;
    DEP_address_4_to[2] = 0;
    DEP_time_4_to[2] = 0;
    DEP_address_4_to[3] = 0;
    DEP_time_4_to[3] = 0;
    DEP_address_4_to[4] = 0;
    DEP_time_4_to[4] = 0;
    DEP_address_4_to[5] = 0;
    DEP_time_4_to[5] = 0;
    DEP_address_4_to[6] = 0;
    DEP_time_4_to[6] = 0;
    DEP_address_4_to[7] = 0;
    DEP_time_4_to[7] = 0;
    DEP_address_4_to[8] = 0;
    DEP_time_4_to[8] = 0;
    DEP_address_4_to[9] = 0;
    DEP_time_4_to[9] = 0;
    DEP_address_4_to[10] = 0;
    DEP_time_4_to[10] = 0;
    DEP_address_4_to[11] = 0;
    DEP_time_4_to[11] = 0;
    DEP_address_4_to[12] = 0;
    DEP_time_4_to[12] = 0;
    DEP_address_4_from[0] = 0;
    DEP_time_4_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_4_to[12] = DEP_address_4_to[11];
            DEP_time_4_to[12] = DEP_time_4_to[11];
            DEP_address_4_to[11] = DEP_address_4_to[10];
            DEP_time_4_to[11] = DEP_time_4_to[10];
            DEP_address_4_to[10] = DEP_address_4_to[9];
            DEP_time_4_to[10] = DEP_time_4_to[9];
            DEP_address_4_to[9] = DEP_address_4_to[8];
            DEP_time_4_to[9] = DEP_time_4_to[8];
            DEP_address_4_to[8] = DEP_address_4_to[7];
            DEP_time_4_to[8] = DEP_time_4_to[7];
            DEP_address_4_to[7] = DEP_address_4_to[6];
            DEP_time_4_to[7] = DEP_time_4_to[6];
            DEP_address_4_to[6] = DEP_address_4_to[5];
            DEP_time_4_to[6] = DEP_time_4_to[5];
            DEP_address_4_to[5] = DEP_address_4_to[4];
            DEP_time_4_to[5] = DEP_time_4_to[4];
            DEP_address_4_to[4] = DEP_address_4_to[3];
            DEP_time_4_to[4] = DEP_time_4_to[3];
            DEP_address_4_to[3] = DEP_address_4_to[2];
            DEP_time_4_to[3] = DEP_time_4_to[2];
            DEP_address_4_to[2] = DEP_address_4_to[1];
            DEP_time_4_to[2] = DEP_time_4_to[1];
            DEP_address_4_to[1] = DEP_address_4_to[0];
            DEP_time_4_to[1] = DEP_time_4_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1135) begin
                DEP_address_4_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_4_address0};
                DEP_time_4_to[0] = $time;
            end else begin
                DEP_address_4_to[0] = {1'b0, 4'b0};
                DEP_time_4_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_4_to[12] = DEP_address_4_to[11];
            DEP_time_4_to[12] = DEP_time_4_to[11];
            DEP_address_4_to[11] = DEP_address_4_to[10];
            DEP_time_4_to[11] = DEP_time_4_to[10];
            DEP_address_4_to[10] = DEP_address_4_to[9];
            DEP_time_4_to[10] = DEP_time_4_to[9];
            DEP_address_4_to[9] = DEP_address_4_to[8];
            DEP_time_4_to[9] = DEP_time_4_to[8];
            DEP_address_4_to[8] = DEP_address_4_to[7];
            DEP_time_4_to[8] = DEP_time_4_to[7];
            DEP_address_4_to[7] = DEP_address_4_to[6];
            DEP_time_4_to[7] = DEP_time_4_to[6];
            DEP_address_4_to[6] = DEP_address_4_to[5];
            DEP_time_4_to[6] = DEP_time_4_to[5];
            DEP_address_4_to[5] = DEP_address_4_to[4];
            DEP_time_4_to[5] = DEP_time_4_to[4];
            DEP_address_4_to[4] = DEP_address_4_to[3];
            DEP_time_4_to[4] = DEP_time_4_to[3];
            DEP_address_4_to[3] = DEP_address_4_to[2];
            DEP_time_4_to[3] = DEP_time_4_to[2];
            DEP_address_4_to[2] = DEP_address_4_to[1];
            DEP_time_4_to[2] = DEP_time_4_to[1];
            DEP_address_4_to[1] = DEP_address_4_to[0];
            DEP_time_4_to[1] = DEP_time_4_to[0];
            DEP_address_4_to[0] = {1'b0, 4'b0};
            DEP_time_4_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1335) begin
                if (DEP_address_4_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_4_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_4_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_4_address1};
                DEP_time_4_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1335) begin
                DEP_i_4 = 0;
                if (DEP_address_4_to[0][4]) begin
                    DEP_error_4 = (DEP_address_4_to[0][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[0][3:0], DEP_time_4_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[1][4]) begin
                    DEP_error_4 = (DEP_address_4_to[1][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[1][3:0], DEP_time_4_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[2][4]) begin
                    DEP_error_4 = (DEP_address_4_to[2][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[2][3:0], DEP_time_4_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[3][4]) begin
                    DEP_error_4 = (DEP_address_4_to[3][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[3][3:0], DEP_time_4_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[4][4]) begin
                    DEP_error_4 = (DEP_address_4_to[4][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[4][3:0], DEP_time_4_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[5][4]) begin
                    DEP_error_4 = (DEP_address_4_to[5][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[5][3:0], DEP_time_4_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[6][4]) begin
                    DEP_error_4 = (DEP_address_4_to[6][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[6][3:0], DEP_time_4_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[7][4]) begin
                    DEP_error_4 = (DEP_address_4_to[7][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[7][3:0], DEP_time_4_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[8][4]) begin
                    DEP_error_4 = (DEP_address_4_to[8][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[8][3:0], DEP_time_4_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[9][4]) begin
                    DEP_error_4 = (DEP_address_4_to[9][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[9][3:0], DEP_time_4_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[10][4]) begin
                    DEP_error_4 = (DEP_address_4_to[10][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[10][3:0], DEP_time_4_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[11][4]) begin
                    DEP_error_4 = (DEP_address_4_to[11][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[11][3:0], DEP_time_4_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_4_to[12][4]) begin
                    DEP_error_4 = (DEP_address_4_to[12][3:0] == DEP_address_4_from[DEP_i_4][3:0]);
                    if (DEP_error_4) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_4_address1\" = 0x%0h @ \"%0t\"", DEP_address_4_from[DEP_i_4][3:0], DEP_time_4_from[DEP_i_4]);
                        $display("//                : To memory access \"acc_4_address0\" = DEP_address_4_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_4_to[12][3:0], DEP_time_4_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1335"(W:SV18-18) -> "ap_enable_operation_1135"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_4_from[DEP_i_4] = {1'b0, 4'b0};
                DEP_time_4_from[DEP_i_4] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_5_to [13 - 1:0];
time DEP_time_5_to [13 - 1:0];
reg [4:0] DEP_address_5_from [1 - 1:0];
time DEP_time_5_from [1 - 1:0];
reg DEP_error_5 = 0;
integer DEP_i_5;

initial begin
    DEP_address_5_to[0] = 0;
    DEP_time_5_to[0] = 0;
    DEP_address_5_to[1] = 0;
    DEP_time_5_to[1] = 0;
    DEP_address_5_to[2] = 0;
    DEP_time_5_to[2] = 0;
    DEP_address_5_to[3] = 0;
    DEP_time_5_to[3] = 0;
    DEP_address_5_to[4] = 0;
    DEP_time_5_to[4] = 0;
    DEP_address_5_to[5] = 0;
    DEP_time_5_to[5] = 0;
    DEP_address_5_to[6] = 0;
    DEP_time_5_to[6] = 0;
    DEP_address_5_to[7] = 0;
    DEP_time_5_to[7] = 0;
    DEP_address_5_to[8] = 0;
    DEP_time_5_to[8] = 0;
    DEP_address_5_to[9] = 0;
    DEP_time_5_to[9] = 0;
    DEP_address_5_to[10] = 0;
    DEP_time_5_to[10] = 0;
    DEP_address_5_to[11] = 0;
    DEP_time_5_to[11] = 0;
    DEP_address_5_to[12] = 0;
    DEP_time_5_to[12] = 0;
    DEP_address_5_from[0] = 0;
    DEP_time_5_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_5_to[12] = DEP_address_5_to[11];
            DEP_time_5_to[12] = DEP_time_5_to[11];
            DEP_address_5_to[11] = DEP_address_5_to[10];
            DEP_time_5_to[11] = DEP_time_5_to[10];
            DEP_address_5_to[10] = DEP_address_5_to[9];
            DEP_time_5_to[10] = DEP_time_5_to[9];
            DEP_address_5_to[9] = DEP_address_5_to[8];
            DEP_time_5_to[9] = DEP_time_5_to[8];
            DEP_address_5_to[8] = DEP_address_5_to[7];
            DEP_time_5_to[8] = DEP_time_5_to[7];
            DEP_address_5_to[7] = DEP_address_5_to[6];
            DEP_time_5_to[7] = DEP_time_5_to[6];
            DEP_address_5_to[6] = DEP_address_5_to[5];
            DEP_time_5_to[6] = DEP_time_5_to[5];
            DEP_address_5_to[5] = DEP_address_5_to[4];
            DEP_time_5_to[5] = DEP_time_5_to[4];
            DEP_address_5_to[4] = DEP_address_5_to[3];
            DEP_time_5_to[4] = DEP_time_5_to[3];
            DEP_address_5_to[3] = DEP_address_5_to[2];
            DEP_time_5_to[3] = DEP_time_5_to[2];
            DEP_address_5_to[2] = DEP_address_5_to[1];
            DEP_time_5_to[2] = DEP_time_5_to[1];
            DEP_address_5_to[1] = DEP_address_5_to[0];
            DEP_time_5_to[1] = DEP_time_5_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1137) begin
                DEP_address_5_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_5_address0};
                DEP_time_5_to[0] = $time;
            end else begin
                DEP_address_5_to[0] = {1'b0, 4'b0};
                DEP_time_5_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_5_to[12] = DEP_address_5_to[11];
            DEP_time_5_to[12] = DEP_time_5_to[11];
            DEP_address_5_to[11] = DEP_address_5_to[10];
            DEP_time_5_to[11] = DEP_time_5_to[10];
            DEP_address_5_to[10] = DEP_address_5_to[9];
            DEP_time_5_to[10] = DEP_time_5_to[9];
            DEP_address_5_to[9] = DEP_address_5_to[8];
            DEP_time_5_to[9] = DEP_time_5_to[8];
            DEP_address_5_to[8] = DEP_address_5_to[7];
            DEP_time_5_to[8] = DEP_time_5_to[7];
            DEP_address_5_to[7] = DEP_address_5_to[6];
            DEP_time_5_to[7] = DEP_time_5_to[6];
            DEP_address_5_to[6] = DEP_address_5_to[5];
            DEP_time_5_to[6] = DEP_time_5_to[5];
            DEP_address_5_to[5] = DEP_address_5_to[4];
            DEP_time_5_to[5] = DEP_time_5_to[4];
            DEP_address_5_to[4] = DEP_address_5_to[3];
            DEP_time_5_to[4] = DEP_time_5_to[3];
            DEP_address_5_to[3] = DEP_address_5_to[2];
            DEP_time_5_to[3] = DEP_time_5_to[2];
            DEP_address_5_to[2] = DEP_address_5_to[1];
            DEP_time_5_to[2] = DEP_time_5_to[1];
            DEP_address_5_to[1] = DEP_address_5_to[0];
            DEP_time_5_to[1] = DEP_time_5_to[0];
            DEP_address_5_to[0] = {1'b0, 4'b0};
            DEP_time_5_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1337) begin
                if (DEP_address_5_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_5_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_5_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_5_address1};
                DEP_time_5_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1337) begin
                DEP_i_5 = 0;
                if (DEP_address_5_to[0][4]) begin
                    DEP_error_5 = (DEP_address_5_to[0][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[0][3:0], DEP_time_5_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[1][4]) begin
                    DEP_error_5 = (DEP_address_5_to[1][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[1][3:0], DEP_time_5_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[2][4]) begin
                    DEP_error_5 = (DEP_address_5_to[2][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[2][3:0], DEP_time_5_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[3][4]) begin
                    DEP_error_5 = (DEP_address_5_to[3][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[3][3:0], DEP_time_5_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[4][4]) begin
                    DEP_error_5 = (DEP_address_5_to[4][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[4][3:0], DEP_time_5_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[5][4]) begin
                    DEP_error_5 = (DEP_address_5_to[5][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[5][3:0], DEP_time_5_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[6][4]) begin
                    DEP_error_5 = (DEP_address_5_to[6][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[6][3:0], DEP_time_5_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[7][4]) begin
                    DEP_error_5 = (DEP_address_5_to[7][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[7][3:0], DEP_time_5_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[8][4]) begin
                    DEP_error_5 = (DEP_address_5_to[8][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[8][3:0], DEP_time_5_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[9][4]) begin
                    DEP_error_5 = (DEP_address_5_to[9][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[9][3:0], DEP_time_5_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[10][4]) begin
                    DEP_error_5 = (DEP_address_5_to[10][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[10][3:0], DEP_time_5_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[11][4]) begin
                    DEP_error_5 = (DEP_address_5_to[11][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[11][3:0], DEP_time_5_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_5_to[12][4]) begin
                    DEP_error_5 = (DEP_address_5_to[12][3:0] == DEP_address_5_from[DEP_i_5][3:0]);
                    if (DEP_error_5) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_5_address1\" = 0x%0h @ \"%0t\"", DEP_address_5_from[DEP_i_5][3:0], DEP_time_5_from[DEP_i_5]);
                        $display("//                : To memory access \"acc_5_address0\" = DEP_address_5_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_5_to[12][3:0], DEP_time_5_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1337"(W:SV18-18) -> "ap_enable_operation_1137"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_5_from[DEP_i_5] = {1'b0, 4'b0};
                DEP_time_5_from[DEP_i_5] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_6_to [13 - 1:0];
time DEP_time_6_to [13 - 1:0];
reg [4:0] DEP_address_6_from [1 - 1:0];
time DEP_time_6_from [1 - 1:0];
reg DEP_error_6 = 0;
integer DEP_i_6;

initial begin
    DEP_address_6_to[0] = 0;
    DEP_time_6_to[0] = 0;
    DEP_address_6_to[1] = 0;
    DEP_time_6_to[1] = 0;
    DEP_address_6_to[2] = 0;
    DEP_time_6_to[2] = 0;
    DEP_address_6_to[3] = 0;
    DEP_time_6_to[3] = 0;
    DEP_address_6_to[4] = 0;
    DEP_time_6_to[4] = 0;
    DEP_address_6_to[5] = 0;
    DEP_time_6_to[5] = 0;
    DEP_address_6_to[6] = 0;
    DEP_time_6_to[6] = 0;
    DEP_address_6_to[7] = 0;
    DEP_time_6_to[7] = 0;
    DEP_address_6_to[8] = 0;
    DEP_time_6_to[8] = 0;
    DEP_address_6_to[9] = 0;
    DEP_time_6_to[9] = 0;
    DEP_address_6_to[10] = 0;
    DEP_time_6_to[10] = 0;
    DEP_address_6_to[11] = 0;
    DEP_time_6_to[11] = 0;
    DEP_address_6_to[12] = 0;
    DEP_time_6_to[12] = 0;
    DEP_address_6_from[0] = 0;
    DEP_time_6_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_6_to[12] = DEP_address_6_to[11];
            DEP_time_6_to[12] = DEP_time_6_to[11];
            DEP_address_6_to[11] = DEP_address_6_to[10];
            DEP_time_6_to[11] = DEP_time_6_to[10];
            DEP_address_6_to[10] = DEP_address_6_to[9];
            DEP_time_6_to[10] = DEP_time_6_to[9];
            DEP_address_6_to[9] = DEP_address_6_to[8];
            DEP_time_6_to[9] = DEP_time_6_to[8];
            DEP_address_6_to[8] = DEP_address_6_to[7];
            DEP_time_6_to[8] = DEP_time_6_to[7];
            DEP_address_6_to[7] = DEP_address_6_to[6];
            DEP_time_6_to[7] = DEP_time_6_to[6];
            DEP_address_6_to[6] = DEP_address_6_to[5];
            DEP_time_6_to[6] = DEP_time_6_to[5];
            DEP_address_6_to[5] = DEP_address_6_to[4];
            DEP_time_6_to[5] = DEP_time_6_to[4];
            DEP_address_6_to[4] = DEP_address_6_to[3];
            DEP_time_6_to[4] = DEP_time_6_to[3];
            DEP_address_6_to[3] = DEP_address_6_to[2];
            DEP_time_6_to[3] = DEP_time_6_to[2];
            DEP_address_6_to[2] = DEP_address_6_to[1];
            DEP_time_6_to[2] = DEP_time_6_to[1];
            DEP_address_6_to[1] = DEP_address_6_to[0];
            DEP_time_6_to[1] = DEP_time_6_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1139) begin
                DEP_address_6_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_6_address0};
                DEP_time_6_to[0] = $time;
            end else begin
                DEP_address_6_to[0] = {1'b0, 4'b0};
                DEP_time_6_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_6_to[12] = DEP_address_6_to[11];
            DEP_time_6_to[12] = DEP_time_6_to[11];
            DEP_address_6_to[11] = DEP_address_6_to[10];
            DEP_time_6_to[11] = DEP_time_6_to[10];
            DEP_address_6_to[10] = DEP_address_6_to[9];
            DEP_time_6_to[10] = DEP_time_6_to[9];
            DEP_address_6_to[9] = DEP_address_6_to[8];
            DEP_time_6_to[9] = DEP_time_6_to[8];
            DEP_address_6_to[8] = DEP_address_6_to[7];
            DEP_time_6_to[8] = DEP_time_6_to[7];
            DEP_address_6_to[7] = DEP_address_6_to[6];
            DEP_time_6_to[7] = DEP_time_6_to[6];
            DEP_address_6_to[6] = DEP_address_6_to[5];
            DEP_time_6_to[6] = DEP_time_6_to[5];
            DEP_address_6_to[5] = DEP_address_6_to[4];
            DEP_time_6_to[5] = DEP_time_6_to[4];
            DEP_address_6_to[4] = DEP_address_6_to[3];
            DEP_time_6_to[4] = DEP_time_6_to[3];
            DEP_address_6_to[3] = DEP_address_6_to[2];
            DEP_time_6_to[3] = DEP_time_6_to[2];
            DEP_address_6_to[2] = DEP_address_6_to[1];
            DEP_time_6_to[2] = DEP_time_6_to[1];
            DEP_address_6_to[1] = DEP_address_6_to[0];
            DEP_time_6_to[1] = DEP_time_6_to[0];
            DEP_address_6_to[0] = {1'b0, 4'b0};
            DEP_time_6_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1339) begin
                if (DEP_address_6_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_6_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_6_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_6_address1};
                DEP_time_6_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1339) begin
                DEP_i_6 = 0;
                if (DEP_address_6_to[0][4]) begin
                    DEP_error_6 = (DEP_address_6_to[0][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[0][3:0], DEP_time_6_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[1][4]) begin
                    DEP_error_6 = (DEP_address_6_to[1][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[1][3:0], DEP_time_6_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[2][4]) begin
                    DEP_error_6 = (DEP_address_6_to[2][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[2][3:0], DEP_time_6_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[3][4]) begin
                    DEP_error_6 = (DEP_address_6_to[3][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[3][3:0], DEP_time_6_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[4][4]) begin
                    DEP_error_6 = (DEP_address_6_to[4][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[4][3:0], DEP_time_6_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[5][4]) begin
                    DEP_error_6 = (DEP_address_6_to[5][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[5][3:0], DEP_time_6_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[6][4]) begin
                    DEP_error_6 = (DEP_address_6_to[6][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[6][3:0], DEP_time_6_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[7][4]) begin
                    DEP_error_6 = (DEP_address_6_to[7][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[7][3:0], DEP_time_6_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[8][4]) begin
                    DEP_error_6 = (DEP_address_6_to[8][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[8][3:0], DEP_time_6_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[9][4]) begin
                    DEP_error_6 = (DEP_address_6_to[9][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[9][3:0], DEP_time_6_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[10][4]) begin
                    DEP_error_6 = (DEP_address_6_to[10][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[10][3:0], DEP_time_6_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[11][4]) begin
                    DEP_error_6 = (DEP_address_6_to[11][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[11][3:0], DEP_time_6_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_6_to[12][4]) begin
                    DEP_error_6 = (DEP_address_6_to[12][3:0] == DEP_address_6_from[DEP_i_6][3:0]);
                    if (DEP_error_6) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_6_address1\" = 0x%0h @ \"%0t\"", DEP_address_6_from[DEP_i_6][3:0], DEP_time_6_from[DEP_i_6]);
                        $display("//                : To memory access \"acc_6_address0\" = DEP_address_6_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_6_to[12][3:0], DEP_time_6_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1339"(W:SV18-18) -> "ap_enable_operation_1139"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_6_from[DEP_i_6] = {1'b0, 4'b0};
                DEP_time_6_from[DEP_i_6] = 0;
            end
        end // of check access
    end 
end

// Dependence Check (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
reg [4:0] DEP_address_7_to [13 - 1:0];
time DEP_time_7_to [13 - 1:0];
reg [4:0] DEP_address_7_from [1 - 1:0];
time DEP_time_7_from [1 - 1:0];
reg DEP_error_7 = 0;
integer DEP_i_7;

initial begin
    DEP_address_7_to[0] = 0;
    DEP_time_7_to[0] = 0;
    DEP_address_7_to[1] = 0;
    DEP_time_7_to[1] = 0;
    DEP_address_7_to[2] = 0;
    DEP_time_7_to[2] = 0;
    DEP_address_7_to[3] = 0;
    DEP_time_7_to[3] = 0;
    DEP_address_7_to[4] = 0;
    DEP_time_7_to[4] = 0;
    DEP_address_7_to[5] = 0;
    DEP_time_7_to[5] = 0;
    DEP_address_7_to[6] = 0;
    DEP_time_7_to[6] = 0;
    DEP_address_7_to[7] = 0;
    DEP_time_7_to[7] = 0;
    DEP_address_7_to[8] = 0;
    DEP_time_7_to[8] = 0;
    DEP_address_7_to[9] = 0;
    DEP_time_7_to[9] = 0;
    DEP_address_7_to[10] = 0;
    DEP_time_7_to[10] = 0;
    DEP_address_7_to[11] = 0;
    DEP_time_7_to[11] = 0;
    DEP_address_7_to[12] = 0;
    DEP_time_7_to[12] = 0;
    DEP_address_7_from[0] = 0;
    DEP_time_7_from[0] = 0;
end

always @ (negedge AESL_clock) begin
    if (~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_block_pp0) begin 
        // record "to" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin 
            DEP_address_7_to[12] = DEP_address_7_to[11];
            DEP_time_7_to[12] = DEP_time_7_to[11];
            DEP_address_7_to[11] = DEP_address_7_to[10];
            DEP_time_7_to[11] = DEP_time_7_to[10];
            DEP_address_7_to[10] = DEP_address_7_to[9];
            DEP_time_7_to[10] = DEP_time_7_to[9];
            DEP_address_7_to[9] = DEP_address_7_to[8];
            DEP_time_7_to[9] = DEP_time_7_to[8];
            DEP_address_7_to[8] = DEP_address_7_to[7];
            DEP_time_7_to[8] = DEP_time_7_to[7];
            DEP_address_7_to[7] = DEP_address_7_to[6];
            DEP_time_7_to[7] = DEP_time_7_to[6];
            DEP_address_7_to[6] = DEP_address_7_to[5];
            DEP_time_7_to[6] = DEP_time_7_to[5];
            DEP_address_7_to[5] = DEP_address_7_to[4];
            DEP_time_7_to[5] = DEP_time_7_to[4];
            DEP_address_7_to[4] = DEP_address_7_to[3];
            DEP_time_7_to[4] = DEP_time_7_to[3];
            DEP_address_7_to[3] = DEP_address_7_to[2];
            DEP_time_7_to[3] = DEP_time_7_to[2];
            DEP_address_7_to[2] = DEP_address_7_to[1];
            DEP_time_7_to[2] = DEP_time_7_to[1];
            DEP_address_7_to[1] = DEP_address_7_to[0];
            DEP_time_7_to[1] = DEP_time_7_to[0];
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1141) begin
                DEP_address_7_to[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_7_address0};
                DEP_time_7_to[0] = $time;
            end else begin
                DEP_address_7_to[0] = {1'b0, 4'b0};
                DEP_time_7_to[0] = $time;
            end
        end // of record to access
        else if( (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state6_pp0_iter5_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state7_pp0_iter6_stage0||
            `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0)
            &&  ~`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter5) begin
            DEP_address_7_to[12] = DEP_address_7_to[11];
            DEP_time_7_to[12] = DEP_time_7_to[11];
            DEP_address_7_to[11] = DEP_address_7_to[10];
            DEP_time_7_to[11] = DEP_time_7_to[10];
            DEP_address_7_to[10] = DEP_address_7_to[9];
            DEP_time_7_to[10] = DEP_time_7_to[9];
            DEP_address_7_to[9] = DEP_address_7_to[8];
            DEP_time_7_to[9] = DEP_time_7_to[8];
            DEP_address_7_to[8] = DEP_address_7_to[7];
            DEP_time_7_to[8] = DEP_time_7_to[7];
            DEP_address_7_to[7] = DEP_address_7_to[6];
            DEP_time_7_to[7] = DEP_time_7_to[6];
            DEP_address_7_to[6] = DEP_address_7_to[5];
            DEP_time_7_to[6] = DEP_time_7_to[5];
            DEP_address_7_to[5] = DEP_address_7_to[4];
            DEP_time_7_to[5] = DEP_time_7_to[4];
            DEP_address_7_to[4] = DEP_address_7_to[3];
            DEP_time_7_to[4] = DEP_time_7_to[3];
            DEP_address_7_to[3] = DEP_address_7_to[2];
            DEP_time_7_to[3] = DEP_time_7_to[2];
            DEP_address_7_to[2] = DEP_address_7_to[1];
            DEP_time_7_to[2] = DEP_time_7_to[1];
            DEP_address_7_to[1] = DEP_address_7_to[0];
            DEP_time_7_to[1] = DEP_time_7_to[0];
            DEP_address_7_to[0] = {1'b0, 4'b0};
            DEP_time_7_to[0] = $time;
        end
        // record "from" access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1341) begin
                if (DEP_address_7_from[0][4]) begin
                    $display("// ERROR : \"DEP_address_7_from[0]\" is overwritten @ \"%0t\"", $time);
                    $display("// autotb LINE:%d", `__LINE__);
                    $display("////////////////////////////////////////////////////////////////////////////////////");
                end
                DEP_address_7_from[0] = {1'b1, `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.acc_7_address1};
                DEP_time_7_from[0] = $time;
            end
        end // of record from access
        // check access
        if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_state19_pp0_iter18_stage0
            &&  `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_reg_pp0_iter18) begin
            if (`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581.ap_enable_operation_1341) begin
                DEP_i_7 = 0;
                if (DEP_address_7_to[0][4]) begin
                    DEP_error_7 = (DEP_address_7_to[0][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 13) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[0][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[0][3:0], DEP_time_7_to[0]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[1][4]) begin
                    DEP_error_7 = (DEP_address_7_to[1][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 12) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[1][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[1][3:0], DEP_time_7_to[1]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[2][4]) begin
                    DEP_error_7 = (DEP_address_7_to[2][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 11) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[2][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[2][3:0], DEP_time_7_to[2]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[3][4]) begin
                    DEP_error_7 = (DEP_address_7_to[3][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 10) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[3][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[3][3:0], DEP_time_7_to[3]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[4][4]) begin
                    DEP_error_7 = (DEP_address_7_to[4][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 9) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[4][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[4][3:0], DEP_time_7_to[4]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[5][4]) begin
                    DEP_error_7 = (DEP_address_7_to[5][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 8) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[5][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[5][3:0], DEP_time_7_to[5]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[6][4]) begin
                    DEP_error_7 = (DEP_address_7_to[6][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 7) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[6][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[6][3:0], DEP_time_7_to[6]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[7][4]) begin
                    DEP_error_7 = (DEP_address_7_to[7][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 6) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[7][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[7][3:0], DEP_time_7_to[7]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[8][4]) begin
                    DEP_error_7 = (DEP_address_7_to[8][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 5) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[8][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[8][3:0], DEP_time_7_to[8]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[9][4]) begin
                    DEP_error_7 = (DEP_address_7_to[9][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 4) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[9][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[9][3:0], DEP_time_7_to[9]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[10][4]) begin
                    DEP_error_7 = (DEP_address_7_to[10][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 3) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[10][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[10][3:0], DEP_time_7_to[10]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[11][4]) begin
                    DEP_error_7 = (DEP_address_7_to[11][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 2) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[11][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[11][3:0], DEP_time_7_to[11]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                if (DEP_address_7_to[12][4]) begin
                    DEP_error_7 = (DEP_address_7_to[12][3:0] == DEP_address_7_from[DEP_i_7][3:0]);
                    if (DEP_error_7) begin
                        $display("//Critical WARNING: Due to pragma (E:/FPGA_competition/AX7020_Project/platform/lung_cnn_lane8/conv.cpp:63:58), dependence access (loop distance = 1) is detected in \"`AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581\"");
                        $display("//                : From memory access \"acc_7_address1\" = 0x%0h @ \"%0t\"", DEP_address_7_from[DEP_i_7][3:0], DEP_time_7_from[DEP_i_7]);
                        $display("//                : To memory access \"acc_7_address0\" = DEP_address_7_to[12][3:0] = 0x%0h @ \"%0t\"", DEP_address_7_to[12][3:0], DEP_time_7_to[12]);
                        $display("//If cosim fails, the WARNING should be checked. autotb LINE:%d", `__LINE__);
                        $display("////////////////////////////////////////////////////////////////////////////////////");
// (RAW) "ap_enable_operation_1341"(W:SV18-18) -> "ap_enable_operation_1141"(R:SV5-6) @ `AUTOTB_DUT_INST.grp_row_pipeline_fu_955.compute_channels_U0.grp_compute_channels_Pipeline_mac_c_mac_x_mac_fu_581
                    end
                end
                DEP_address_7_from[DEP_i_7] = {1'b0, 4'b0};
                DEP_time_7_from[DEP_i_7] = 0;
            end
        end // of check access
    end 
end

`endif

`ifndef POST_SYN
AESL_deadlock_detector deadlock_detector(
    .dl_reset(AESL_reset),
    .all_finish(all_finish),
    .dl_clock(AESL_clock));
`endif

///////////////////////////////////////////////////////
// dataflow status monitor
///////////////////////////////////////////////////////
dataflow_monitor U_dataflow_monitor(
    .clock(AESL_clock),
    .reset(~rst),
    .finish(all_finish));

`include "fifo_para.vh"

endmodule
