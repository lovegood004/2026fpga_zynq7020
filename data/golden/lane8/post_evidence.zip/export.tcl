open_checkpoint {E:/FPGA_competition/AX7020_Project/build_work/lung_cnn_lane8_20261101/system/system/lung_pl.runs/design_1_lung_conv_0_0_synth_1/design_1_lung_conv_0_0.dcp}
write_verilog -force -mode funcsim -rename_top lung_conv_fp32 {E:/FPGA_competition/AX7020_Project/build_work/lung_cnn_lane8_20261101/post_v2/netlist.v}
close_design
exit
